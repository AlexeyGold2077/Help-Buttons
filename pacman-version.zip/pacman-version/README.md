# How to use?
1. Go to the "pacman-version" folder
2. Enter the command - **sudo sh installer/install.sh**
3. Make sure there are no errors and **enjoy using**!
